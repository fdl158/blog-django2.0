from django.apps import AppConfig


class MaincoreappConfig(AppConfig):
    name = 'apps.MainCoreApp'
    verbose_name = u'博客核心设置'
